fetch('https://jsonplaceholder.typicode.com/users')
.then((apidata)=>{
    // console.log(apidata);
    return apidata.json(); 
})
.then((actualdata)=>{
    // console.log(actualdata);
    const mydata = actualdata.name
    console.log(actualdata);

})
.catch((error)=>{
    console.log(error);
})








































// function getData(){
//     url = "https://jsonplaceholder.typicode.com/users";
//     fetch(url).then((response)=>{
//         return response.json();
//     }).then((data)=>{
//         console.log(data);
//     })
// }
// getData()

/*
fetch('https://jsonplaceholder.typicode.com/users')
.then(response => response.json())
.then(json => {
    // console.log(json);
    let str="";
    let dt = document.getElementById("details").value;
    const markup = json.map(el => {
        // for (var j = 0; j < json.length; j++){

        // }
        // console.log(json[0]);
        
        str = `
            <p class="details">
                <div class="showdata">
                    <span>Name:${el.name}</span><br>
                </div>
                <div class="user-email">
                    <span>Email:${el.email}</span><br>
                </div>
                <div>

                </div>
            </p>

        `
        dt.innerHTML=str;
    });

    console.log(markup);
    document.querySelector('.showdata').innerHTML = markup.join('');
  
})

*/
/*  
fetch('https://jsonplaceholder.typicode.com/users')
.then(response => response.json())
.then(json => {
    console.log(json);
    const markup = json.map(el => {
        return `
        
        <li class="card-container">
             <div class="name-container"> 
                 <span>ID:${el.id}</span><br>
                 <span>Name:${el.name}</span><br>
                 <span>User Name:${el.username}</span><br>
                 <span>Email:${el.email}</span><br>
                 <span>Phone:${el.phone}</span><br>
                 <span>Website:${el.website}</span><br>
                 <span>Address:-${el.address.street}</span>
                 <span>${el.address.suite}</span>
                 <span>${el.address.city}</span>
                 <span>${el.address.zipcode}</span>
                 <span>${el.address.geo.lat}</span>
                 <span>${el.address.geo.lng}</span><br>
                 <span>Company:${el.company.name}</span>
                 <span>${el.company.catchPhrase}</span>
                 <span>${el.company.bs}</span>
                
             </div> <br>
            </li>
        `
    });
    console.log(markup);
    document.querySelector('.list-container').innerHTML = markup.join('');
  
}) */
